module.exports = function User(username, area, socketid){
	this.username = username;
	this.area = area;
	this.socketid = socketid;
};